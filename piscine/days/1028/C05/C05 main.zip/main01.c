#include <stdio.h>

int ft_recursive_factorial(int nb);

int main() {
    printf("%d", ft_recursive_factorial(3));
    return 0;
}
