#include <stdio.h>

int ft_sqrt(int nb);

int main() {
    printf("%d", ft_sqrt(16));
    return 0;
}
