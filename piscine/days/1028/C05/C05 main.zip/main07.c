#include <stdio.h>

int ft_find_next_prime(int nb);

int main() {
    printf("%d", ft_find_next_prime(27));
    return 0;
}
