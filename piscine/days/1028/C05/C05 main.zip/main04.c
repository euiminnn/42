#include <stdio.h>

int ft_fibonacci(int nb);

int main() {
    printf("%d", ft_fibonacci(10));
    return 0;
}
