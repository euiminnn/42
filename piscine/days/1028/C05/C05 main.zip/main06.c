#include <stdio.h>

int ft_is_prime(int nb);

int main() {
    printf("%d", ft_is_prime(13));
    return 0;
}
